import React from 'react';
import { Bet, BetStatus } from '../types';
import BetCard from './BetCard';

interface BetListProps {
  bets: Bet[];
  onUpdateStatus: (id: string, status: BetStatus) => void;
  onDelete: (id: string) => void;
  onUpdateBet: (bet: Bet) => void;
}

const BetList: React.FC<BetListProps> = ({ bets, onUpdateStatus, onDelete, onUpdateBet }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {bets.map((bet) => (
        <BetCard
          key={bet.id}
          bet={bet}
          onUpdateStatus={onUpdateStatus}
          onDelete={onDelete}
          onUpdateBet={onUpdateBet}
        />
      ))}
    </div>
  );
};

export default BetList;