import React, { useState } from 'react';
import { Bet, BetStatus } from '../types';
import { PencilIcon } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import { BetTypeTag } from './BetTypeTag';
import { BetActions } from './BetActions';
import { BetDetails } from './BetDetails';
import EditOddsForm from './EditOddsForm';

interface BetCardProps {
  bet: Bet;
  onUpdateStatus: (id: string, status: BetStatus) => void;
  onDelete: (id: string) => void;
  onUpdateBet: (bet: Bet) => void;
}

const BetCard: React.FC<BetCardProps> = ({ bet, onUpdateStatus, onDelete, onUpdateBet }) => {
  const [showEditForm, setShowEditForm] = useState(false);

  const getStatusColor = (status: BetStatus) => {
    switch (status) {
      case 'won':
        return 'bg-green-100 border-green-500';
      case 'lost':
        return 'bg-red-100 border-red-500';
      default:
        return 'bg-yellow-50 border-yellow-500';
    }
  };

  return (
    <>
      <div className={`rounded-lg border-l-4 p-4 ${getStatusColor(bet.status)} shadow-sm`}>
        <div className="flex justify-between items-start mb-2">
          <div>
            <p className="text-sm text-gray-500">
              {new Date(bet.date).toLocaleDateString('es-ES', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
            <h3 className="text-lg font-semibold text-gray-900">{bet.description}</h3>
          </div>
          <div className="flex items-center space-x-2">
            {bet.status === 'pending' && (
              <button
                onClick={() => setShowEditForm(true)}
                className="p-1 text-gray-500 hover:text-blue-600"
                title="Editar cuotas"
              >
                <PencilIcon className="h-5 w-5" />
              </button>
            )}
            <BetTypeTag type={bet.type} />
          </div>
        </div>

        <BetDetails bet={bet} />

        {bet.type === 'combined' && bet.events && (
          <div className="mt-4 space-y-2">
            <h4 className="text-sm font-medium text-gray-700">Eventos:</h4>
            {bet.events.map((event, index) => (
              <div key={index} className="flex justify-between items-center text-sm">
                <span>{event.description}</span>
                <span className="font-medium">{event.odds.toFixed(2)}x</span>
              </div>
            ))}
          </div>
        )}

        <StatusBadge status={bet.status} />
        <BetActions 
          betId={bet.id}
          status={bet.status}
          onUpdateStatus={onUpdateStatus}
          onDelete={onDelete}
        />
      </div>

      {showEditForm && (
        <EditOddsForm
          bet={bet}
          onSave={(updatedBet) => {
            onUpdateBet(updatedBet);
            setShowEditForm(false);
          }}
          onCancel={() => setShowEditForm(false)}
        />
      )}
    </>
  );
};

export default BetCard;