import React, { useState } from 'react';
import { Bet, BetEvent } from '../types';
import { X } from 'lucide-react';

interface EditOddsFormProps {
  bet: Bet;
  onSave: (bet: Bet) => void;
  onCancel: () => void;
}

const EditOddsForm: React.FC<EditOddsFormProps> = ({ bet, onSave, onCancel }) => {
  const [odds, setOdds] = useState(bet.odds.toString());
  const [events, setEvents] = useState<BetEvent[]>(bet.events || []);

  const updateEvent = (index: number, newOdds: string) => {
    const newEvents = [...events];
    newEvents[index] = { ...newEvents[index], odds: parseFloat(newOdds) || 1 };
    setEvents(newEvents);

    if (bet.type === 'combined') {
      const totalOdds = newEvents.reduce((acc, event) => acc * event.odds, 1);
      setOdds(totalOdds.toFixed(2));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedBet: Bet = {
      ...bet,
      odds: parseFloat(odds),
      events: bet.type === 'combined' ? events : undefined,
      possibleWin: bet.amount * parseFloat(odds),
    };
    onSave(updatedBet);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        <div className="p-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-900">Editar Cuotas</h2>
          <button onClick={onCancel} className="text-gray-400 hover:text-gray-500">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {bet.type === 'simple' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700">Cuota</label>
              <input
                type="number"
                value={odds}
                onChange={(e) => setOdds(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                step="0.01"
                min="1"
                required
              />
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="font-medium text-gray-900">Eventos</h3>
              {events.map((event, index) => (
                <div key={index} className="flex gap-4 items-center">
                  <div className="flex-grow">
                    <p className="text-sm text-gray-600">{event.description}</p>
                  </div>
                  <div className="w-32">
                    <input
                      type="number"
                      value={event.odds}
                      onChange={(e) => updateEvent(index, e.target.value)}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      step="0.01"
                      min="1"
                      required
                    />
                  </div>
                </div>
              ))}
              <div className="mt-4 p-4 bg-gray-50 rounded-md">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-700">Cuota Total:</span>
                  <span className="font-bold text-lg">{odds}x</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              Guardar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditOddsForm;