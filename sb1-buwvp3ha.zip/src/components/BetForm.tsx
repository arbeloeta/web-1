import React, { useState } from 'react';
import { Bet, BetType, BetEvent } from '../types';
import { Plus, X } from 'lucide-react';

interface BetFormProps {
  onSubmit: (bet: Bet) => void;
  onCancel: () => void;
}

const BetForm: React.FC<BetFormProps> = ({ onSubmit, onCancel }) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [odds, setOdds] = useState('');
  const [type, setType] = useState<BetType>('simple');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [events, setEvents] = useState<BetEvent[]>([]);

  const addEvent = () => {
    setEvents([...events, { description: '', odds: 1 }]);
  };

  const updateEvent = (index: number, field: keyof BetEvent, value: string) => {
    const newEvents = [...events];
    if (field === 'odds') {
      newEvents[index] = { ...newEvents[index], [field]: parseFloat(value) || 1 };
    } else {
      newEvents[index] = { ...newEvents[index], [field]: value };
    }
    setEvents(newEvents);

    // Update total odds for combined bet
    if (type === 'combined') {
      const totalOdds = newEvents.reduce((acc, event) => acc * event.odds, 1);
      setOdds(totalOdds.toFixed(2));
    }
  };

  const removeEvent = (index: number) => {
    const newEvents = events.filter((_, i) => i !== index);
    setEvents(newEvents);

    // Update total odds after removing event
    if (type === 'combined' && newEvents.length > 0) {
      const totalOdds = newEvents.reduce((acc, event) => acc * event.odds, 1);
      setOdds(totalOdds.toFixed(2));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newBet: Bet = {
      id: Date.now().toString(),
      date,
      description,
      amount: parseFloat(amount),
      odds: parseFloat(odds),
      type,
      status: 'pending',
      possibleWin: parseFloat(amount) * parseFloat(odds),
      events: type === 'combined' ? events : undefined,
    };
    onSubmit(newBet);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4">
        <div className="p-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-900">Nueva Apuesta</h2>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Tipo de Apuesta
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as BetType)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="simple">Simple</option>
                <option value="combined">Combinada</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Fecha
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          {type === 'simple' && (
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Descripción del Evento
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Ej: Real Madrid vs Barcelona"
                required
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Importe
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">€</span>
                </div>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="0.00"
                  step="0.01"
                  min="0"
                  required
                />
              </div>
            </div>
            {type === 'simple' && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Cuota
                </label>
                <input
                  type="number"
                  value={odds}
                  onChange={(e) => setOdds(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="1.00"
                  step="0.01"
                  min="1"
                  required
                />
              </div>
            )}
          </div>

          {type === 'combined' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">Eventos</h3>
                <button
                  type="button"
                  onClick={addEvent}
                  className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Añadir Evento
                </button>
              </div>

              {events.map((event, index) => (
                <div key={index} className="flex gap-4 items-start">
                  <div className="flex-grow">
                    <input
                      type="text"
                      value={event.description}
                      onChange={(e) => updateEvent(index, 'description', e.target.value)}
                      placeholder="Descripción del evento"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      required
                    />
                  </div>
                  <div className="w-32">
                    <input
                      type="number"
                      value={event.odds}
                      onChange={(e) => updateEvent(index, 'odds', e.target.value)}
                      placeholder="Cuota"
                      step="0.01"
                      min="1"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      required
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removeEvent(index)}
                    className="mt-1 p-2 text-gray-400 hover:text-red-500"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              ))}

              {events.length > 0 && (
                <div className="mt-4 p-4 bg-gray-50 rounded-md">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-700">Cuota Total:</span>
                    <span className="font-bold text-lg">
                      {events.reduce((acc, event) => acc * event.odds, 1).toFixed(2)}x
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              Guardar Apuesta
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BetForm;