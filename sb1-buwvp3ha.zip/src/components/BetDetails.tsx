import React from 'react';
import { Bet } from '../types';

interface BetDetailsProps {
  bet: Bet;
}

export const BetDetails: React.FC<BetDetailsProps> = ({ bet }) => (
  <div className="grid grid-cols-2 gap-4 my-4">
    <div>
      <p className="text-sm text-gray-500">Monto</p>
      <p className="text-lg font-semibold">€{bet.amount.toFixed(2)}</p>
    </div>
    <div>
      <p className="text-sm text-gray-500">Cuota</p>
      <p className="text-lg font-semibold">{bet.odds.toFixed(2)}x</p>
    </div>
    <div>
      <p className="text-sm text-gray-500">Posible Ganancia</p>
      <p className="text-lg font-semibold">€{bet.possibleWin.toFixed(2)}</p>
    </div>
    <div>
      <p className="text-sm text-gray-500">Estado</p>
      <div className="flex items-center">
        <span className="text-sm font-medium">
          {bet.status === 'won' ? 'Ganada' : bet.status === 'lost' ? 'Perdida' : 'Pendiente'}
        </span>
      </div>
    </div>
  </div>
);