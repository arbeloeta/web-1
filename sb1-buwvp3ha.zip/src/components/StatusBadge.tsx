import React from 'react';
import { BetStatus } from '../types';
import { CheckCircle, XCircle, Clock } from 'lucide-react';

interface StatusBadgeProps {
  status: BetStatus;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const getStatusIcon = (status: BetStatus) => {
    switch (status) {
      case 'won':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'lost':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-yellow-500" />;
    }
  };

  return (
    <div className="flex items-center">
      {getStatusIcon(status)}
      <span className="ml-1 text-sm font-medium">
        {status === 'won' ? 'Ganada' : status === 'lost' ? 'Perdida' : 'Pendiente'}
      </span>
    </div>
  );
};