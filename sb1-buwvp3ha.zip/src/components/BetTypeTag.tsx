import React from 'react';
import { BetType } from '../types';

interface BetTypeTagProps {
  type: BetType;
}

export const BetTypeTag: React.FC<BetTypeTagProps> = ({ type }) => (
  <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
    {type === 'simple' ? 'Simple' : 'Combinada'}
  </span>
);