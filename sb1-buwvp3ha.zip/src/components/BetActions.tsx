import React from 'react';
import { BetStatus } from '../types';
import { Trash2 } from 'lucide-react';

interface BetActionsProps {
  betId: string;
  status: BetStatus;
  onUpdateStatus: (id: string, status: BetStatus) => void;
  onDelete: (id: string) => void;
}

export const BetActions: React.FC<BetActionsProps> = ({
  betId,
  status,
  onUpdateStatus,
  onDelete,
}) => (
  <div className="flex justify-end space-x-2 mt-4">
    {status === 'pending' && (
      <>
        <button
          onClick={() => onUpdateStatus(betId, 'won')}
          className="px-3 py-1 text-sm font-medium text-green-700 bg-green-100 rounded-md hover:bg-green-200"
        >
          Ganada
        </button>
        <button
          onClick={() => onUpdateStatus(betId, 'lost')}
          className="px-3 py-1 text-sm font-medium text-red-700 bg-red-100 rounded-md hover:bg-red-200"
        >
          Perdida
        </button>
      </>
    )}
    <button
      onClick={() => onDelete(betId)}
      className="p-1 text-gray-500 hover:text-red-600"
      title="Eliminar apuesta"
    >
      <Trash2 className="h-5 w-5" />
    </button>
  </div>
);