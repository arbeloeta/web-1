import React from 'react';
import { TrendingUp } from 'lucide-react';

interface HeaderProps {
  balance: number;
}

export const Header: React.FC<HeaderProps> = ({ balance }) => (
  <header className="bg-white shadow-sm">
    <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
      <div className="flex items-center space-x-2">
        <TrendingUp className="h-6 w-6 text-blue-600" />
        <h1 className="text-2xl font-bold text-gray-900">Mis <span className="text-blue-600">Apuestas</span></h1>
      </div>
      <div className="text-lg font-semibold text-gray-900">
        Balance: €{balance.toFixed(2)}
      </div>
    </div>
  </header>
);